from django.contrib import admin
from .models import apptType

admin.site.register(apptType)