from django.contrib import admin
from .models import consultation 
from .models import consultType

admin.site.register(consultation)
admin.site.register(consultType)
# Register your models here.
