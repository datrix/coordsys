from django.contrib import admin
from .models import CalendarEvent

admin.site.register(CalendarEvent)