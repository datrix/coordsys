from django.contrib import admin
from .models import course
# Register your models here
admin.site.register(course)

