from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.UserFormView.as_view(), name = 'index'),  #homepage
    url(r'^login/test', views.test, name = 'test'),
  
]